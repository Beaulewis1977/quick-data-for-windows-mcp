# Windows Setup Guide for Quick Data MCP

This guide provides detailed setup instructions specifically for Windows users.

## Prerequisites Check

### 1. Python Installation

**Check if Python is installed:**
```cmd
python --version
```

**If not installed or version < 3.9:**
1. Download from [python.org](https://www.python.org/downloads/)
2. **IMPORTANT:** Check "Add Python to PATH" during installation
3. Restart Command Prompt after installation

### 2. Claude Desktop

**Download and install:**
- Go to [claude.ai/desktop](https://claude.ai/desktop)
- Download the Windows version
- Install and create account

## Step-by-Step Installation

### Step 1: Get the Code

**Option A: Download ZIP**
1. Go to https://github.com/Beaulewis1977/quick-data-for-windows-mcp
2. Click "Code" → "Download ZIP"
3. Extract to `C:\Users\YourUsername\quick-data-for-windows-mcp`

**Option B: Git Clone**
```cmd
cd C:\Users\YourUsername
git clone https://github.com/Beaulewis1977/quick-data-for-windows-mcp.git
```

### Step 2: Install Dependencies

```cmd
cd C:\Users\YourUsername\quick-data-for-windows-mcp
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**If you get permission errors:**
```cmd
pip install --user -r requirements.txt
```

### Step 3: Test the Server

```cmd
python main.py
```

**Expected output:**
```
Quick Data for Windows MCP v1.0.0
Server running on stdio...
```

Press `Ctrl+C` to stop the test.

### Step 4: Configure Claude Desktop

**Find your Claude Desktop config directory:**
```cmd
echo %APPDATA%\Claude
```

**Copy and edit configuration:**
```cmd
copy claude_desktop_config.json.sample "%APPDATA%\Claude\claude_desktop_config.json"
```

**Edit the config file:**
1. Open `%APPDATA%\Claude\claude_desktop_config.json` in Notepad
2. Replace `C:\Users\YourUsername\` with your actual username
3. Replace paths to match your installation location

**Example final config:**
```json
{
  "mcpServers": {
    "quick-data-windows": {
      "command": "python",
      "args": [
        "C:\\Users\\John\\quick-data-for-windows-mcp\\main.py"
      ],
      "cwd": "C:\\Users\\John\\quick-data-for-windows-mcp",
      "env": {
        "LOG_LEVEL": "INFO",
        "PYTHONPATH": "C:\\Users\\John\\quick-data-for-windows-mcp\\src"
      }
    }
  }
}
```

### Step 5: Restart Claude Desktop

1. Close Claude Desktop completely
2. Restart it
3. The MCP server should now be available

## Verification

### Test in Claude Desktop

Type this command:
```
Use the quick-data-windows server to list loaded datasets
```

**Expected response:** Information about the MCP server being available.

### Test Data Loading

1. Create a test CSV file at `C:\Users\YourUsername\test_data.csv`:
```csv
name,age,city
John,25,New York
Jane,30,Los Angeles
Bob,35,Chicago
```

2. In Claude Desktop:
```
Load the file C:\Users\YourUsername\test_data.csv as "test"
```

3. Then try:
```
Show me the correlations in the test dataset
```

## Troubleshooting Windows-Specific Issues

### Python PATH Issues

**Problem:** `'python' is not recognized as an internal or external command`

**Solution:**
1. Reinstall Python with "Add to PATH" checked
2. Or manually add Python to PATH:
   - Open System Properties → Environment Variables
   - Add `C:\Users\YourUsername\AppData\Local\Programs\Python\Python3X` to PATH

### Permission Issues

**Problem:** `Permission denied` when installing packages

**Solutions:**
```cmd
# Option 1: Install for current user only
pip install --user -r requirements.txt

# Option 2: Run as administrator
# Right-click Command Prompt → "Run as administrator"
pip install -r requirements.txt
```

### File Path Issues

**Problem:** File not found errors in Claude Desktop

**Solutions:**
- Always use full paths: `C:\Users\John\Documents\data.csv`
- Never use relative paths: `.\data.csv` or `data.csv`
- Use forward slashes or escaped backslashes in Claude: `C:/Users/John/data.csv`

### Config File Issues

**Problem:** Claude Desktop doesn't recognize the server

**Checklist:**
1. Config file location: `%APPDATA%\Claude\claude_desktop_config.json`
2. Valid JSON syntax (use JSON validator online)
3. Correct file paths (no typos)
4. Claude Desktop restarted after config changes

### Large Dataset Issues

**Problem:** Memory errors with large files

**Solutions:**
```
# Use sampling when loading large files
Load C:\path\to\large_file.csv as "data" with sample size 10000

# Clear datasets when done
Clear all datasets
```

## Advanced Configuration

### Using UV Package Manager (Recommended)

If you install UV for better Python dependency management:

```cmd
pip install uv
```

Update your config to use UV:
```json
{
  "mcpServers": {
    "quick-data-windows": {
      "command": "uv",
      "args": [
        "--directory",
        "C:\\Users\\YourUsername\\quick-data-for-windows-mcp",
        "run",
        "python",
        "main.py"
      ]
    }
  }
}
```

### Custom Python Environment

If using virtual environments:

```cmd
# Create virtual environment
python -m venv venv

# Activate it
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Update config to use venv Python
# Use: C:\path\to\project\venv\Scripts\python.exe
```

## Getting Help

### Check System Information
```cmd
python --version
pip --version
where python
echo %APPDATA%
```

### Test Dependencies
```cmd
python -c "import pandas; print('pandas OK')"
python -c "import plotly; print('plotly OK')"
python -c "import mcp; print('mcp OK')"
```

### Common Error Messages

**"No module named 'pandas'"**
- Run: `pip install pandas`

**"No module named 'mcp_server'"**
- Check PYTHONPATH in config file
- Verify project directory structure

**"Server failed to start"**
- Test server manually: `python main.py`
- Check Claude Desktop logs

Need more help? Open an issue on GitHub with:
1. Windows version
2. Python version
3. Error messages
4. Config file contents (remove personal paths)