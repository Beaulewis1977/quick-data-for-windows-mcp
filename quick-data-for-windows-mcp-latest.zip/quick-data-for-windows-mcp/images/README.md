# Images

This folder contains screenshots and visual documentation for the Quick Data for Windows MCP project.

## Files

- `claude-desktop-mcp-connected.png` - Screenshot showing the Quick Data Windows MCP server successfully connected to Claude Desktop with 20 available tools

## Usage

These images can be referenced in documentation to help users verify their installation is working correctly.