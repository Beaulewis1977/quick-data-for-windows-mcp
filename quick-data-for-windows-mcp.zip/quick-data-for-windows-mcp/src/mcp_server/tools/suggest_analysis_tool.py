"""Analysis suggestion tool."""
from ..models.schemas import DatasetManager, dataset_schemas

async def suggest_analysis(dataset_name: str) -> dict:
    try:
        df = DatasetManager.get_dataset(dataset_name)
        schema = dataset_schemas.get(dataset_name)
        
        suggestions = []
        if schema:
            suggestions = schema.suggested_analyses
        
        # Add basic suggestions based on data
        numeric_cols = len(df.select_dtypes(include=['number']).columns)
        categorical_cols = len(df.select_dtypes(include=['object']).columns)
        
        if numeric_cols > 1:
            suggestions.append("correlation_analysis")
        if categorical_cols > 0:
            suggestions.append("segmentation_analysis")
        
        return {
            "status": "success",
            "suggestions": list(set(suggestions)),
            "numeric_columns": numeric_cols,
            "categorical_columns": categorical_cols
        }
    except Exception as e:
        return {"status": "error", "message": f"Analysis suggestion failed: {str(e)}"}