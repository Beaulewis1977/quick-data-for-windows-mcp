"""Clear dataset tool."""

from ..models.schemas import DatasetManager


async def clear_dataset(dataset_name: str) -> dict:
    """Remove specific dataset from memory."""
    try:
        success = DatasetManager.clear_dataset(dataset_name)
        
        if success:
            return {
                "status": "success",
                "message": f"Dataset '{dataset_name}' removed from memory"
            }
        else:
            return {
                "status": "error",
                "message": f"Dataset '{dataset_name}' not found"
            }
            
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to clear dataset: {str(e)}"
        }