"""Correlation analysis tool."""

from typing import Optional, List
from ..models.schemas import DatasetManager


async def find_correlations(
    dataset_name: str, 
    columns: Optional[List[str]] = None,
    threshold: float = 0.3
) -> dict:
    """Find correlations between numerical columns."""
    try:
        df = DatasetManager.get_dataset(dataset_name)
        
        # Select numerical columns
        numeric_df = df.select_dtypes(include=['number'])
        if columns:
            numeric_df = numeric_df[columns]
        
        if numeric_df.empty:
            return {"status": "error", "message": "No numerical columns found"}
        
        # Calculate correlations
        corr_matrix = numeric_df.corr()
        
        # Find strong correlations above threshold
        strong_correlations = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                col1, col2 = corr_matrix.columns[i], corr_matrix.columns[j]
                corr_value = corr_matrix.iloc[i, j]
                if abs(corr_value) >= threshold:
                    strong_correlations.append({
                        "column1": col1,
                        "column2": col2,
                        "correlation": round(corr_value, 3)
                    })
        
        return {
            "status": "success",
            "correlations": strong_correlations,
            "threshold": threshold,
            "correlation_matrix": corr_matrix.round(3).to_dict()
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Correlation analysis failed: {str(e)}"
        }