"""Segmentation analysis tool."""

from typing import Optional
from ..models.schemas import DatasetManager


async def segment_by_column(
    dataset_name: str, 
    column_name: str, 
    method: str = "auto",
    top_n: int = 10
) -> dict:
    """Generic segmentation that works on any categorical column."""
    try:
        df = DatasetManager.get_dataset(dataset_name)
        
        if column_name not in df.columns:
            return {"status": "error", "message": f"Column '{column_name}' not found"}
        
        # Count values and get top N
        value_counts = df[column_name].value_counts().head(top_n)
        
        segments = []
        for value, count in value_counts.items():
            percentage = (count / len(df)) * 100
            segments.append({
                "value": str(value),
                "count": int(count),
                "percentage": round(percentage, 2)
            })
        
        return {
            "status": "success",
            "column": column_name,
            "total_unique_values": df[column_name].nunique(),
            "segments": segments,
            "method": method
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Segmentation failed: {str(e)}"
        }