"""Clear all datasets tool."""

from ..models.schemas import DatasetManager


async def clear_all_datasets() -> dict:
    """Clear all datasets from memory."""
    try:
        count = DatasetManager.clear_all_datasets()
        
        return {
            "status": "success",
            "message": f"Cleared {count} datasets from memory"
        }
            
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to clear datasets: {str(e)}"
        }