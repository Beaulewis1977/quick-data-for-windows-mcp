"""Server configuration settings optimized for Windows."""

import os
import platform
from typing import Optional
from pathlib import Path


class Settings:
    """Application settings with Windows-specific optimizations."""
    
    def __init__(self):
        self.server_name = "Quick Data for Windows MCP"
        self.version = "1.0.0"
        self.log_level = os.getenv("LOG_LEVEL", "INFO")
        self.api_key: Optional[str] = os.getenv("API_KEY")
        self.database_url: Optional[str] = os.getenv("DATABASE_URL")
        
        # Windows-specific settings
        self.is_windows = platform.system() == "Windows"
        self.temp_dir = self._get_temp_dir()
        self.default_data_dir = self._get_default_data_dir()
        
    def _get_temp_dir(self) -> str:
        """Get appropriate temp directory for the platform."""
        if self.is_windows:
            return os.getenv("TEMP", "C:\\Windows\\Temp")
        return "/tmp"
    
    def _get_default_data_dir(self) -> str:
        """Get default data directory for the platform."""
        if self.is_windows:
            documents = os.path.join(os.path.expanduser("~"), "Documents")
            return os.path.join(documents, "QuickDataMCP")
        return os.path.join(os.path.expanduser("~"), "quick_data_mcp")
    
    def normalize_path(self, path: str) -> str:
        """Normalize path for the current platform."""
        return str(Path(path).resolve())
    
    @property
    def server_info(self) -> dict:
        """Get server information."""
        return {
            "name": self.server_name,
            "version": self.version,
            "log_level": self.log_level,
            "platform": platform.system(),
            "is_windows": self.is_windows,
            "temp_dir": self.temp_dir,
            "default_data_dir": self.default_data_dir
        }


settings = Settings()