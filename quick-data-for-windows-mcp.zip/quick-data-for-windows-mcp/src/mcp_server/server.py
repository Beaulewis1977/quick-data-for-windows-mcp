"""Main MCP server implementation optimized for Windows and Claude Desktop."""

from mcp.server import FastMCP
from .config.settings import settings
from .models.schemas import ChartConfig
from . import tools
from typing import List, Optional, Dict, Any


# Create the FastMCP server instance
mcp = FastMCP(
    name=settings.server_name,
    version=settings.version,
    dependencies=["pydantic>=2.0.0", "pandas>=2.2.3", "plotly>=6.1.2"]
)


# ============================================================================
# DATASET MANAGEMENT TOOLS
# ============================================================================

@mcp.tool()
async def load_dataset(file_path: str, dataset_name: str, sample_size: Optional[int] = None) -> dict:
    """Load any JSON/CSV dataset into memory with Windows path handling."""
    return await tools.load_dataset(file_path, dataset_name, sample_size)


@mcp.tool()
async def list_loaded_datasets() -> dict:
    """Show all datasets currently in memory."""
    return await tools.list_loaded_datasets()


@mcp.tool()
async def get_dataset_info(dataset_name: str) -> dict:
    """Get comprehensive dataset information."""
    return await tools.get_dataset_info(dataset_name)


@mcp.tool()
async def clear_dataset(dataset_name: str) -> dict:
    """Remove specific dataset from memory."""
    return await tools.clear_dataset(dataset_name)

@mcp.tool()
async def clear_all_datasets() -> dict:
    """Clear all datasets from memory."""
    return await tools.clear_all_datasets()


# ============================================================================
# ANALYTICS TOOLS - Core data analysis functions
# ============================================================================

@mcp.tool()
async def segment_by_column(
    dataset_name: str, 
    column_name: str, 
    method: str = "auto",
    top_n: int = 10
) -> dict:
    """Generic segmentation that works on any categorical column."""
    return await tools.segment_by_column(dataset_name, column_name, method, top_n)


@mcp.tool()
async def find_correlations(
    dataset_name: str, 
    columns: Optional[List[str]] = None,
    threshold: float = 0.3
) -> dict:
    """Find correlations between numerical columns."""
    return await tools.find_correlations(dataset_name, columns, threshold)


@mcp.tool()
async def analyze_distributions(dataset_name: str, column_name: str) -> dict:
    """Analyze distribution of any column."""
    return await tools.analyze_distributions(dataset_name, column_name)


@mcp.tool()
async def detect_outliers(
    dataset_name: str, 
    columns: Optional[List[str]] = None,
    method: str = "iqr"
) -> dict:
    """Detect outliers using configurable methods."""
    return await tools.detect_outliers(dataset_name, columns, method)


@mcp.tool()
async def time_series_analysis(
    dataset_name: str, 
    date_column: str, 
    value_column: str,
    frequency: str = "auto"
) -> dict:
    """Temporal analysis when dates are detected."""
    return await tools.time_series_analysis(dataset_name, date_column, value_column, frequency)


@mcp.tool()
async def suggest_analysis(dataset_name: str) -> dict:
    """AI recommendations based on data characteristics."""
    return await tools.suggest_analysis(dataset_name)


# ============================================================================
# VISUALIZATION TOOLS - Chart creation with Windows path support
# ============================================================================

@mcp.tool()
async def create_chart(
    dataset_name: str,
    chart_type: str,
    x_column: str,
    y_column: Optional[str] = None,
    groupby_column: Optional[str] = None,
    title: Optional[str] = None,
    save_path: Optional[str] = None
) -> dict:
    """Create generic charts that adapt to any dataset with Windows path handling."""
    return await tools.create_chart(
        dataset_name, chart_type, x_column, y_column, groupby_column, title, save_path
    )


@mcp.tool()
async def generate_dashboard(dataset_name: str, chart_configs: List[Dict[str, Any]]) -> dict:
    """Generate multi-chart dashboards from any data."""
    return await tools.generate_dashboard(dataset_name, chart_configs)


# ============================================================================
# ADVANCED ANALYTICS TOOLS - Complex analysis functions
# ============================================================================

@mcp.tool()
async def validate_data_quality(dataset_name: str) -> dict:
    """Comprehensive data quality assessment."""
    return await tools.validate_data_quality(dataset_name)


@mcp.tool()
async def compare_datasets(dataset_a: str, dataset_b: str, common_columns: Optional[List[str]] = None) -> dict:
    """Compare multiple datasets."""
    return await tools.compare_datasets(dataset_a, dataset_b, common_columns)


@mcp.tool()
async def merge_datasets(
    dataset_configs: List[Dict[str, Any]], 
    join_strategy: str = "inner"
) -> dict:
    """Join datasets on common keys."""
    return await tools.merge_datasets(dataset_configs, join_strategy)


@mcp.tool()
async def export_insights(dataset_name: str, format: str = "json", include_charts: bool = False) -> dict:
    """Export analysis in multiple formats."""
    return await tools.export_insights(dataset_name, format, include_charts)


@mcp.tool()
async def calculate_feature_importance(
    dataset_name: str, 
    target_column: str, 
    feature_columns: Optional[List[str]] = None
) -> dict:
    """Calculate feature importance for predictive modeling."""
    return await tools.calculate_feature_importance(dataset_name, target_column, feature_columns)


@mcp.tool()
async def memory_optimization_report(dataset_name: str) -> dict:
    """Performance analysis and memory optimization suggestions."""
    return await tools.memory_optimization_report(dataset_name)


@mcp.tool()
async def execute_custom_analytics_code(dataset_name: str, python_code: str) -> dict:
    """Execute custom Python code against datasets."""
    return await tools.execute_custom_analytics_code(dataset_name, python_code)