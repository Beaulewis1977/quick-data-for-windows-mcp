# Example Data Files

This directory contains sample data files to test the Quick Data for Windows MCP server.

## Files Included

### sample_sales_data.csv
- **Description:** Sample e-commerce sales data
- **Columns:** product_id, product_name, category, price, quantity_sold, revenue, region, sales_date, customer_type
- **Rows:** 10 sample records
- **Use Cases:** 
  - Test correlation analysis between price and quantity_sold
  - Create charts showing revenue by region
  - Segment analysis by customer_type or category

### sample_customer_data.json
- **Description:** Customer demographics and purchase history
- **Columns:** customer_id, name, age, email, city, country, signup_date, total_purchases, total_spent, customer_tier
- **Rows:** 5 sample records
- **Use Cases:**
  - Analyze customer distribution by country/city
  - Correlate age with total_spent
  - Segment customers by tier
  - Time series analysis of signup dates

## Testing Commands

Once you have the MCP server running in Claude Desktop, try these commands:

### Load the Data
```
Load the file C:\path\to\your\quick-data-for-windows-mcp\examples\sample_sales_data.csv as "sales"
Load the file C:\path\to\your\quick-data-for-windows-mcp\examples\sample_customer_data.json as "customers"
```

### Basic Analysis
```
Show me correlations in the sales dataset
Analyze the distribution of revenue in sales dataset
Segment the sales data by category
Create a bar chart of revenue by region using the sales dataset
```

### Advanced Analysis
```
Validate data quality for sales dataset
Compare sales and customers datasets
Generate dashboard with sales by region and customer tier distribution
```

### Data Management
```
List all loaded datasets
Get detailed info for sales dataset
Clear the customers dataset
```

## Creating Your Own Test Data

You can create additional test files:

### CSV Format
- First row must contain column headers
- Use standard CSV format with commas as separators
- Encoding should be UTF-8
- Date formats: YYYY-MM-DD recommended

### JSON Format
- Array of objects format (like sample_customer_data.json)
- Flat structure preferred (nested objects will be flattened)
- Use consistent data types across records

## Windows Path Examples

When using these files in Claude Desktop, remember to use full Windows paths:

```
# Correct Windows paths:
C:\Users\YourName\quick-data-for-windows-mcp\examples\sample_sales_data.csv
C:\Users\YourName\Documents\my_data.csv
D:\Projects\data\analysis.json

# Alternative format (also works):
C:/Users/YourName/quick-data-for-windows-mcp/examples/sample_sales_data.csv
```

## File Size Recommendations

- **Small files (< 1MB):** Load completely
- **Medium files (1-10MB):** Consider sampling: `Load file.csv as "data" with sample size 1000`
- **Large files (> 10MB):** Always use sampling for initial exploration

Have fun exploring your data! 🚀