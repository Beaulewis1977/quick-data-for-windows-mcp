"""Basic test of core functionality without MCP dependencies."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from mcp_server.config.settings import settings
from mcp_server.models.schemas import DatasetManager

def test_settings():
    """Test settings configuration."""
    print("Testing settings...")
    print(f"Server name: {settings.server_name}")
    print(f"Version: {settings.version}")
    print(f"Is Windows: {settings.is_windows}")
    print(f"Temp dir: {settings.temp_dir}")
    print("✓ Settings test passed")

def test_path_normalization():
    """Test Windows path handling."""
    print("\nTesting path normalization...")
    
    test_paths = [
        "C:\\Users\\Test\\data.csv",
        "C:/Users/Test/data.csv",
        "data.csv",
        "/tmp/data.csv"
    ]
    
    for path in test_paths:
        normalized = settings.normalize_path(path)
        print(f"  {path} -> {normalized}")
    
    print("✓ Path normalization test passed")

def test_dataset_manager():
    """Test DatasetManager basic functionality."""
    print("\nTesting DatasetManager...")
    
    # Test path normalization
    test_path = "C:\\Users\\Test\\data.csv"
    normalized = DatasetManager.normalize_path(test_path)
    print(f"Normalized path: {normalized}")
    
    # Test empty dataset list
    datasets = DatasetManager.list_datasets()
    print(f"Empty dataset list: {datasets}")
    assert datasets == []
    
    print("✓ DatasetManager test passed")

if __name__ == "__main__":
    print("Quick Data for Windows MCP - Basic Tests")
    print("=" * 50)
    
    try:
        test_settings()
        test_path_normalization()
        test_dataset_manager()
        
        print("\n" + "=" * 50)
        print("✅ All basic tests passed!")
        print("The core Windows functionality is working correctly.")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)