"""Test project structure and basic imports."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_project_structure():
    """Test that all required files and directories exist."""
    print("Testing project structure...")
    
    required_files = [
        "main.py",
        "requirements.txt",
        "pyproject.toml",
        "README.md",
        "LICENSE",
        "windows-setup.bat",
        "claude_desktop_config.json.sample",
        ".mcp.json.sample",
        "src/mcp_server/__init__.py",
        "src/mcp_server/server.py",
        "src/mcp_server/config/settings.py",
        "src/mcp_server/models/schemas.py",
        "src/mcp_server/tools/__init__.py",
        "examples/sample_sales_data.csv",
        "examples/sample_customer_data.json"
    ]
    
    base_dir = os.path.dirname(__file__)
    missing_files = []
    
    for file_path in required_files:
        full_path = os.path.join(base_dir, file_path)
        if not os.path.exists(full_path):
            missing_files.append(file_path)
        else:
            print(f"  ✓ {file_path}")
    
    if missing_files:
        print(f"\n❌ Missing files: {missing_files}")
        return False
    
    print("✓ All required files present")
    return True

def test_config_files():
    """Test configuration files are valid."""
    print("\nTesting configuration files...")
    
    # Test requirements.txt
    with open("requirements.txt", "r") as f:
        requirements = f.read()
        required_packages = ["mcp[cli]", "pandas", "plotly", "numpy", "scikit-learn", "pydantic"]
        for package in required_packages:
            if package.split("[")[0] in requirements:
                print(f"  ✓ {package} found in requirements")
            else:
                print(f"  ❌ {package} missing from requirements")
    
    print("✓ Requirements file test passed")

def test_windows_paths():
    """Test Windows path handling logic."""
    print("\nTesting Windows path logic...")
    
    from pathlib import Path
    
    # Test Windows-style paths
    win_path = "C:\\Users\\Test\\data.csv"
    normalized = str(Path(win_path).resolve())
    print(f"  Windows path: {win_path} -> {normalized}")
    
    # Test Unix-style paths  
    unix_path = "/tmp/data.csv"
    normalized = str(Path(unix_path).resolve())
    print(f"  Unix path: {unix_path} -> {normalized}")
    
    print("✓ Path handling test passed")

if __name__ == "__main__":
    print("Quick Data for Windows MCP - Structure Tests")
    print("=" * 60)
    
    try:
        success = True
        success &= test_project_structure()
        test_config_files()
        test_windows_paths()
        
        print("\n" + "=" * 60)
        if success:
            print("✅ All structure tests passed!")
            print("Project is ready for deployment to Windows with Claude Desktop.")
        else:
            print("❌ Some tests failed. Check the output above.")
            
    except Exception as e:
        print(f"\n❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()