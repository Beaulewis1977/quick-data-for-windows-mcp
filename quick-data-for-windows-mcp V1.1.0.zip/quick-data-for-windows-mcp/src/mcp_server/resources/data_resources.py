"""Data resources for MCP server."""

from ..models.schemas import loaded_datasets, dataset_schemas


async def get_loaded_datasets() -> dict:
    """Get list of all loaded datasets."""
    return {
        "datasets": list(loaded_datasets.keys()),
        "count": len(loaded_datasets)
    }


async def get_dataset_schema(dataset_name: str) -> dict:
    """Get schema for a specific dataset."""
    if dataset_name not in dataset_schemas:
        return {"error": f"Dataset '{dataset_name}' not found"}
    
    return dataset_schemas[dataset_name].dict()


async def get_dataset_summary(dataset_name: str) -> dict:
    """Get statistical summary of dataset."""
    if dataset_name not in loaded_datasets:
        return {"error": f"Dataset '{dataset_name}' not found"}
    
    df = loaded_datasets[dataset_name]
    return {
        "dataset_name": dataset_name,
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": list(df.columns),
        "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2)
    }