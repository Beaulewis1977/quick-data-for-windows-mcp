"""Analysis prompts for MCP server."""

from ..models.schemas import loaded_datasets, dataset_schemas


async def dataset_first_look(dataset_name: str) -> str:
    """Guide initial exploration of a dataset."""
    if dataset_name not in loaded_datasets:
        return f"Dataset '{dataset_name}' not found. Please load it first."
    
    df = loaded_datasets[dataset_name]
    schema = dataset_schemas.get(dataset_name)
    
    prompt = f"""Let's explore the '{dataset_name}' dataset! Here's what I can see:

📊 **Dataset Overview:**
- {len(df)} rows and {len(df.columns)} columns
- Columns: {', '.join(df.columns[:5])}{'...' if len(df.columns) > 5 else ''}

🔍 **Suggested Analysis Steps:**
1. **Data Quality Check:** `validate_data_quality("{dataset_name}")`
2. **Basic Statistics:** `get_dataset_info("{dataset_name}")` 
3. **Correlations:** `find_correlations("{dataset_name}")`

📈 **Visualization Ideas:**"""
    
    # Add visualization suggestions based on columns
    numeric_cols = df.select_dtypes(include=['number']).columns
    categorical_cols = df.select_dtypes(include=['object']).columns
    
    if len(numeric_cols) >= 2:
        prompt += f"\n- Scatter plot: `create_chart(\"{dataset_name}\", \"scatter\", \"{numeric_cols[0]}\", \"{numeric_cols[1]}\")`"
    
    if len(categorical_cols) > 0:
        prompt += f"\n- Bar chart: `create_chart(\"{dataset_name}\", \"bar\", \"{categorical_cols[0]}\")`"
    
    if len(numeric_cols) > 0:
        prompt += f"\n- Histogram: `create_chart(\"{dataset_name}\", \"histogram\", \"{numeric_cols[0]}\")`"
    
    prompt += f"\n\n🚀 **Ready to dive in?** What aspect interests you most?"
    
    return prompt


async def list_mcp_assets() -> str:
    """List all available MCP server capabilities."""
    return """🛠️ **Quick Data for Windows MCP - Available Tools:**

📂 **Dataset Management:**
- `load_dataset(file_path, dataset_name)` - Load CSV/JSON files
- `list_loaded_datasets()` - Show all datasets in memory
- `get_dataset_info(dataset_name)` - Detailed dataset information
- `clear_dataset(dataset_name)` - Remove dataset from memory

📊 **Analysis Tools:**
- `find_correlations(dataset_name)` - Find relationships between variables
- `segment_by_column(dataset_name, column_name)` - Analyze categorical segments
- `analyze_distributions(dataset_name, column_name)` - Statistical analysis
- `detect_outliers(dataset_name)` - Identify data anomalies
- `suggest_analysis(dataset_name)` - AI-powered recommendations

📈 **Visualization:**
- `create_chart(dataset_name, chart_type, x_column, y_column)` - Interactive charts
- `generate_dashboard(dataset_name, chart_configs)` - Multi-chart dashboards

🔍 **Quality & Advanced:**
- `validate_data_quality(dataset_name)` - Comprehensive quality assessment
- `compare_datasets(dataset_a, dataset_b)` - Multi-dataset comparison
- `export_insights(dataset_name, format)` - Export results

💡 **Getting Started:**
1. Load data: `load_dataset("C:/path/to/file.csv", "my_data")`
2. Explore: `/quick-data-windows:dataset_first_look("my_data")`
3. Analyze and visualize based on suggestions!"""