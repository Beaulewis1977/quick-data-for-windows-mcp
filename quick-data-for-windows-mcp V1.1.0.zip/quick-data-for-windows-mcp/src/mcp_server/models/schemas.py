"""Data models and schemas for analytics platform with Windows optimizations."""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from enum import Enum
import pandas as pd
import numpy as np
import os
from pathlib import Path
import json


class ColumnInfo(BaseModel):
    """Column metadata and characteristics."""
    name: str
    dtype: str
    unique_values: int
    null_percentage: float
    sample_values: List[Any]
    suggested_role: str  # 'categorical', 'numerical', 'temporal', 'identifier'


class DatasetSchema(BaseModel):
    """Dynamically discovered dataset schema."""
    name: str
    columns: Dict[str, ColumnInfo]
    row_count: int
    suggested_analyses: List[str]


class ChartConfig(BaseModel):
    """Chart configuration for plotting."""
    type: str = Field(..., description="Chart type (bar, scatter, line, etc.)")
    x_column: str = Field(..., description="X-axis column name")
    y_column: Optional[str] = Field(None, description="Y-axis column name")
    color_column: Optional[str] = Field(None, description="Color grouping column")
    title: Optional[str] = Field(None, description="Chart title")

# Global in-memory storage for datasets
loaded_datasets: Dict[str, pd.DataFrame] = {}
dataset_schemas: Dict[str, DatasetSchema] = {}


class DatasetManager:
    """Windows-optimized dataset management with proper path handling."""
    
    @staticmethod
    def normalize_path(file_path: str) -> str:
        """Normalize file path for Windows compatibility."""
        return str(Path(file_path).resolve())
    
    @staticmethod
    def load_dataset(file_path: str, dataset_name: str) -> dict:
        """Load dataset with Windows path handling."""
        try:
            # Normalize the path for Windows
            normalized_path = DatasetManager.normalize_path(file_path)
            
            # Check if file exists
            if not Path(normalized_path).exists():
                raise FileNotFoundError(f"File not found: {normalized_path}")
            
            # Determine file type and load accordingly
            file_extension = Path(normalized_path).suffix.lower()
            
            if file_extension == '.csv':
                df = pd.read_csv(normalized_path, encoding='utf-8')
            elif file_extension == '.json':
                df = pd.read_json(normalized_path)
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
            
            # Store the dataset
            loaded_datasets[dataset_name] = df
            
            # Generate schema
            schema = DatasetManager._generate_schema(df, dataset_name)
            dataset_schemas[dataset_name] = schema
            
            return {
                "status": "success",
                "dataset_name": dataset_name,
                "file_path": normalized_path,
                "rows": len(df),
                "columns": list(df.columns),
                "schema": schema.dict()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to load dataset: {str(e)}"
            }
    
    @staticmethod
    def _generate_schema(df: pd.DataFrame, dataset_name: str) -> DatasetSchema:
        """Generate dataset schema with column analysis."""
        columns_info = {}
        suggested_analyses = []
        
        for col in df.columns:
            col_info = DatasetManager._analyze_column(df[col])
            columns_info[col] = col_info
            
        # Suggest analyses based on column types
        numerical_cols = [col for col, info in columns_info.items() 
                         if info.suggested_role == 'numerical']
        categorical_cols = [col for col, info in columns_info.items() 
                           if info.suggested_role == 'categorical']
        
        if len(numerical_cols) > 1:
            suggested_analyses.append("correlation_analysis")
        if categorical_cols:
            suggested_analyses.append("segmentation")
        if numerical_cols:
            suggested_analyses.append("distribution_analysis")
            
        return DatasetSchema(
            name=dataset_name,
            columns=columns_info,
            row_count=len(df),
            suggested_analyses=suggested_analyses
        )
    
    @staticmethod
    def _analyze_column(series: pd.Series) -> ColumnInfo:
        """Analyze a single column to determine its characteristics."""
        # Basic statistics
        unique_values = series.nunique()
        null_percentage = (series.isnull().sum() / len(series)) * 100
        
        # Sample values (non-null)
        sample_values = series.dropna().head(5).tolist()
        
        # Determine column role
        if pd.api.types.is_numeric_dtype(series):
            suggested_role = "numerical"
        elif pd.api.types.is_datetime64_any_dtype(series):
            suggested_role = "temporal"
        elif unique_values == len(series):
            suggested_role = "identifier"
        else:
            suggested_role = "categorical"
            
        return ColumnInfo(
            name=series.name,
            dtype=str(series.dtype),
            unique_values=unique_values,
            null_percentage=round(null_percentage, 2),
            sample_values=sample_values,
            suggested_role=suggested_role
        )
    
    @staticmethod
    def get_dataset(dataset_name: str) -> pd.DataFrame:
        """Get dataset by name."""
        if dataset_name not in loaded_datasets:
            raise ValueError(f"Dataset '{dataset_name}' not found")
        return loaded_datasets[dataset_name]
    
    @staticmethod
    def list_datasets() -> List[str]:
        """List all loaded datasets."""
        return list(loaded_datasets.keys())
    
    @staticmethod
    def clear_dataset(dataset_name: str) -> bool:
        """Remove a dataset from memory."""
        if dataset_name in loaded_datasets:
            del loaded_datasets[dataset_name]
            if dataset_name in dataset_schemas:
                del dataset_schemas[dataset_name]
            return True
        return False
    
    @staticmethod
    def clear_all_datasets() -> int:
        """Clear all datasets from memory."""
        count = len(loaded_datasets)
        loaded_datasets.clear()
        dataset_schemas.clear()
        return count