"""Outlier detection tool."""
from typing import Optional, List
from ..models.schemas import DatasetManager
import numpy as np

async def detect_outliers(dataset_name: str, columns: Optional[List[str]] = None, method: str = "iqr") -> dict:
    try:
        df = DatasetManager.get_dataset(dataset_name)
        numeric_df = df.select_dtypes(include=['number'])
        if columns:
            numeric_df = numeric_df[[c for c in columns if c in numeric_df.columns]]
        
        outliers = {}
        for col in numeric_df.columns:
            if method == "iqr":
                Q1, Q3 = numeric_df[col].quantile([0.25, 0.75])
                IQR = Q3 - Q1
                lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
                outlier_mask = (numeric_df[col] < lower) | (numeric_df[col] > upper)
            else:  # z-score method
                z_scores = np.abs((numeric_df[col] - numeric_df[col].mean()) / numeric_df[col].std())
                outlier_mask = z_scores > 3
            
            outliers[col] = int(outlier_mask.sum())
        
        return {"status": "success", "outliers": outliers, "method": method}
    except Exception as e:
        return {"status": "error", "message": f"Outlier detection failed: {str(e)}"}