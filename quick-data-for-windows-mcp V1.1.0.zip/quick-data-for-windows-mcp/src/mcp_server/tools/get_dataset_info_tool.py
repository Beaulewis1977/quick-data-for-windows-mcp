"""Get dataset information tool."""

from ..models.schemas import DatasetManager, dataset_schemas


async def get_dataset_info(dataset_name: str) -> dict:
    """Get comprehensive dataset information."""
    try:
        if dataset_name not in dataset_schemas:
            return {
                "status": "error",
                "message": f"Dataset '{dataset_name}' not found"
            }
        
        df = DatasetManager.get_dataset(dataset_name)
        schema = dataset_schemas[dataset_name]
        
        return {
            "status": "success",
            "dataset_name": dataset_name,
            "rows": len(df),
            "columns": len(df.columns),
            "schema": schema.dict(),
            "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
            "dtypes": df.dtypes.to_dict()
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to get dataset info: {str(e)}"
        }