"""Chart creation tool with Windows path handling."""

import plotly.express as px
import plotly.graph_objects as go
from typing import Optional
from pathlib import Path
from ..models.schemas import DatasetManager


async def create_chart(
    dataset_name: str,
    chart_type: str,
    x_column: str,
    y_column: Optional[str] = None,
    groupby_column: Optional[str] = None,
    title: Optional[str] = None,
    save_path: Optional[str] = None
) -> dict:
    """Create charts with Windows path handling."""
    try:
        df = DatasetManager.get_dataset(dataset_name)
        
        # Validate columns exist
        if x_column not in df.columns:
            return {"status": "error", "message": f"Column '{x_column}' not found"}
        
        if y_column and y_column not in df.columns:
            return {"status": "error", "message": f"Column '{y_column}' not found"}
            
        # Create chart based on type
        if chart_type.lower() == "bar":
            if groupby_column:
                fig = px.bar(df, x=x_column, y=y_column, color=groupby_column, title=title)
            else:
                fig = px.bar(df, x=x_column, y=y_column, title=title)
        elif chart_type.lower() == "scatter":
            fig = px.scatter(df, x=x_column, y=y_column, color=groupby_column, title=title)
        elif chart_type.lower() == "line":
            fig = px.line(df, x=x_column, y=y_column, color=groupby_column, title=title)
        elif chart_type.lower() == "histogram":
            fig = px.histogram(df, x=x_column, title=title)
        else:
            return {"status": "error", "message": f"Unsupported chart type: {chart_type}"}
        
        # Save chart if path provided
        if save_path:
            # Normalize path for Windows
            normalized_path = str(Path(save_path).resolve())
            fig.write_html(normalized_path)
            
        return {
            "status": "success",
            "chart_type": chart_type,
            "chart_html": fig.to_html(),
            "saved_to": normalized_path if save_path else None
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create chart: {str(e)}"
        }