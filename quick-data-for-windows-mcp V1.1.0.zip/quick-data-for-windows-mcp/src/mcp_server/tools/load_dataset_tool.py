"""Dataset loading tool with Windows path optimization."""

import pandas as pd
import numpy as np
from typing import Optional
from pathlib import Path
from ..models.schemas import DatasetManager, loaded_datasets, dataset_schemas


async def load_dataset(file_path: str, dataset_name: str, sample_size: Optional[int] = None) -> dict:
    """Load any JSON/CSV dataset into memory with Windows path handling."""
    try:
        # Normalize path for Windows
        normalized_path = str(Path(file_path).resolve())
        
        # Load dataset using the manager
        result = DatasetManager.load_dataset(normalized_path, dataset_name)
        
        if result["status"] == "error":
            return result
        
        # Apply sampling if requested
        if sample_size and sample_size < result["rows"]:
            df = DatasetManager.get_dataset(dataset_name)
            sampled_df = df.sample(n=sample_size, random_state=42)
            loaded_datasets[dataset_name] = sampled_df
            
            # Update schema for sampled data
            schema = dataset_schemas[dataset_name]
            schema.row_count = len(sampled_df)
            
            result["rows"] = len(sampled_df)
            result["sampled"] = True
            result["original_rows"] = len(df)
        
        return result
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to load dataset: {str(e)}",
            "file_path": file_path
        }