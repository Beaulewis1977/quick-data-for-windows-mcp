"""List loaded datasets tool."""

from ..models.schemas import loaded_datasets, dataset_schemas


async def list_loaded_datasets() -> dict:
    """Show all datasets currently in memory with statistics."""
    try:
        if not loaded_datasets:
            return {
                "status": "success",
                "message": "No datasets loaded",
                "datasets": []
            }
        
        datasets_info = []
        for name, df in loaded_datasets.items():
            schema = dataset_schemas.get(name)
            info = {
                "name": name,
                "rows": len(df),
                "columns": len(df.columns),
                "column_names": list(df.columns),
                "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
                "suggested_analyses": schema.suggested_analyses if schema else []
            }
            datasets_info.append(info)
        
        return {
            "status": "success",
            "total_datasets": len(datasets_info),
            "datasets": datasets_info
        }
        
    except Exception as e:
        return {
            "status": "error", 
            "message": f"Failed to list datasets: {str(e)}"
        }