"""Distribution analysis tool."""
from ..models.schemas import DatasetManager

async def analyze_distributions(dataset_name: str, column_name: str) -> dict:
    try:
        df = DatasetManager.get_dataset(dataset_name)
        if column_name not in df.columns:
            return {"status": "error", "message": f"Column '{column_name}' not found"}
        
        col = df[column_name]
        return {
            "status": "success",
            "column": column_name,
            "mean": float(col.mean()) if col.dtype in ['int64', 'float64'] else None,
            "median": float(col.median()) if col.dtype in ['int64', 'float64'] else None,
            "std": float(col.std()) if col.dtype in ['int64', 'float64'] else None,
            "min": float(col.min()) if col.dtype in ['int64', 'float64'] else str(col.min()),
            "max": float(col.max()) if col.dtype in ['int64', 'float64'] else str(col.max()),
            "unique_count": int(col.nunique()),
            "null_count": int(col.isnull().sum())
        }
    except Exception as e:
        return {"status": "error", "message": f"Analysis failed: {str(e)}"}