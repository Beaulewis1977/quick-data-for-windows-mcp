# Repository Structure

## Overview
This is a **Windows-optimized fork** of [disler/quick-data-mcp](https://github.com/disler/quick-data-mcp) designed to work seamlessly with Claude Desktop on Windows.

## File Organization

### 🚀 Quick Start Files
- `install_dependencies.bat` - **START HERE** - Automated dependency installation
- `test_server.bat` - Verify installation works
- `run_server.bat` - Smart server launcher (handles Python paths)
- `claude_desktop_config_fixed.json` - Working Claude Desktop configuration

### 📚 Documentation
- `README.md` - Main documentation with setup instructions
- `TROUBLESHOOTING.md` - Windows-specific issue resolution
- `WINDOWS_SETUP_GUIDE.md` - Detailed Windows installation guide
- `ATTRIBUTION.md` - Credits to original project and contributors
- `SUCCESS_STORY.md` - How this fork solves Windows issues

### 🐍 Core Server Code
```
src/mcp_server/
├── server.py              # Main MCP server (32+ tools)
├── config/
│   └── settings.py         # Windows-optimized configuration
├── models/
│   └── schemas.py          # Data models with Windows path handling
├── tools/                  # Analytics tools (inherited from original)
│   ├── load_dataset_tool.py
│   ├── find_correlations_tool.py
│   ├── create_chart_tool.py
│   └── [30+ other tools]
├── resources/              # MCP resources (optional)
└── prompts/                # MCP prompts (optional)
```

### 📊 Example Data
```
examples/
├── sample_sales_data.csv   # Test CSV data
├── sample_customer_data.json # Test JSON data
└── README.md               # Usage examples
```

### ⚙️ Configuration
- `pyproject.toml` - Python package configuration
- `requirements.txt` - Dependencies list
- `.gitignore` - Git ignore patterns
- `LICENSE` - MIT license (same as original)

## Key Differences from Original

### Files Added for Windows Support
- **Batch Files:** `*.bat` files for automated setup and execution
- **Fixed Configuration:** `claude_desktop_config_fixed.json`
- **Troubleshooting:** `TROUBLESHOOTING.md` with Windows-specific guidance
- **Enhanced Documentation:** Windows setup guides

### Files Enhanced for Windows
- **Path Handling:** All tools now use `pathlib.Path` for Windows compatibility
- **Configuration:** Settings now detect Windows environment
- **Error Handling:** Better error messages for Windows users

### Original Files Preserved
- **Core Functionality:** All 32+ analytics tools work identically
- **Server Architecture:** Same MCP server structure
- **Data Processing:** Identical pandas/plotly/sklearn integration
- **License:** Same MIT license terms

## Usage Patterns

### New User (Recommended Path)
1. Run `install_dependencies.bat`
2. Run `test_server.bat` to verify
3. Copy `claude_desktop_config_fixed.json` to Claude Desktop
4. Restart Claude Desktop
5. Start analyzing data!

### Advanced User
1. Examine `src/mcp_server/server.py` for tool definitions
2. Modify tools in `src/mcp_server/tools/` as needed
3. Update `requirements.txt` for additional dependencies
4. Use `run_server.bat` for custom Python environments

### Developer
1. Study original project: [disler/quick-data-mcp](https://github.com/disler/quick-data-mcp)
2. Understand Windows adaptations in this fork
3. Contribute improvements to either repository
4. Maintain attribution to original work

## Maintenance

### Syncing with Original
This fork can be updated to incorporate improvements from the original project while preserving Windows-specific enhancements.

### Contributing Guidelines
- **Windows Issues:** Contribute to this fork
- **Core Functionality:** Contribute to [original project](https://github.com/disler/quick-data-mcp)
- **Documentation:** Both repositories welcome improvements

### Version Management
- Fork version tracks Windows-specific improvements
- Original project version tracks core functionality
- Both versions maintained in documentation

## Architecture Notes

### MCP Server Pattern
Both repositories follow the same MCP server architecture:
- Tools: Functions that AI can call
- Resources: Data that AI can read
- Prompts: Conversation templates

### Windows Adaptations
- **Path Resolution:** Cross-platform file handling
- **Environment Setup:** Robust Python environment detection
- **Error Recovery:** Graceful handling of Windows-specific issues

---

**This structure preserves the original's excellent architecture while adding Windows reliability.** 🏗️